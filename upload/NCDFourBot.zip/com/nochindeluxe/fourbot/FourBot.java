package com.nochindeluxe.fourbot;

public class FourBot {

    public static void main(String[] args) {
        GameParser gameParser = new GameParser();
        gameParser.run();
    }
  
}
